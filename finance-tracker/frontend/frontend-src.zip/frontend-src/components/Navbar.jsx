import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LayoutDashboard, ArrowLeftRight, Tag, LogOut, Sparkles } from 'lucide-react';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const linkClass = ({ isActive }) =>
    `flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
      isActive
        ? 'bg-[var(--color-accent-glow)] text-[var(--color-accent)] shadow-[0_0_20px_rgba(16,185,129,0.1)]'
        : 'text-[var(--color-text-secondary)] hover:text-white hover:bg-[#111111]'
    }`;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-[var(--color-border)] bg-black/80 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-16">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--color-accent)] to-emerald-700 flex items-center justify-center">
            <Sparkles size={16} className="text-black" />
          </div>
          <span className="text-lg font-semibold tracking-tight">
            Fin<span className="text-[var(--color-accent)]">Track</span>
          </span>
        </div>

        {/* Nav Links */}
        <div className="flex items-center gap-1">
          <NavLink to="/dashboard" className={linkClass}>
            <LayoutDashboard size={16} />
            Dashboard
          </NavLink>
          <NavLink to="/transactions" className={linkClass}>
            <ArrowLeftRight size={16} />
            Transactions
          </NavLink>
          <NavLink to="/categories" className={linkClass}>
            <Tag size={16} />
            Categories
          </NavLink>
        </div>

        {/* User + Logout */}
        <div className="flex items-center gap-4">
          <span className="text-sm text-[var(--color-text-secondary)]">
            {user?.name}
          </span>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm text-[var(--color-text-secondary)] hover:text-[var(--color-danger)] hover:bg-[var(--color-danger-dim)]/20 transition-all duration-300"
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
